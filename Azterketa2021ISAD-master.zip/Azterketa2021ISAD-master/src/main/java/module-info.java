open module azterketa {
  requires javafx.graphics;
  requires javafx.controls;
  requires javafx.fxml;
  requires javafx.swing;
  requires java.desktop;
  requires java.sql;
  requires org.apache.commons.codec;
  exports ehu.isad;
}
