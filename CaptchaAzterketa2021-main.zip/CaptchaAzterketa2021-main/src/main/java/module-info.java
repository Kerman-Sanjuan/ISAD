open module azterketa {
  requires javafx.graphics;
  requires javafx.controls;
  requires javafx.fxml;
  requires javafx.swing;
  requires com.google.gson;
  requires java.desktop;
  requires java.sql;
  exports ehu.isad;
}
