package ehu.isad.model;

public class ProbaModel {

    private String xx1;
    private String xx2;

    public ProbaModel(String xx1, String xx2) {
        this.xx1=xx1;
        this.xx2=xx2;
    }
}
