open module azterketa {
  requires javafx.graphics;
  requires javafx.controls;
  requires javafx.fxml;
  requires java.desktop;
  requires java.sql;
  requires com.google.gson;
  exports ehu.isad;
}
