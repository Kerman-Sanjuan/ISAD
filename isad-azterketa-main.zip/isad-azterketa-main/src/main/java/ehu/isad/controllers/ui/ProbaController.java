package ehu.isad.controllers.ui;

import javafx.fxml.FXML;

public class ProbaController {


    private static ProbaController instance=new ProbaController();

    private ProbaController() {}

    public static ProbaController getInstance() {
        return instance;
    }

    @FXML
    void initialize() {

    }
}
