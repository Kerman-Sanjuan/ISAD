open module oinarria {
  requires javafx.graphics;
  requires javafx.controls;
  requires javafx.fxml;
  requires com.google.gson;
  exports ehu.isad;
}
